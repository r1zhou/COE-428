// Raymond Zhou
// XXXX20889

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

extern int pop();
extern int getSize();
extern int heapSize();
extern int heapDelete();
extern void push(int);
extern void addHeap(int);
extern void printTree(int);
extern void sortHeap(int);

int main(int argc, char * argv[])
{
  int value;
  int i;
  int tagCnt;
  int del;

  while (scanf("%d\n", &value) != EOF) // reads integer input values until EOF
  {
    fprintf(stderr, "READING INPUT: %d\n", value);
    tagCnt += 1;
    addHeap(value);
  }
	printTree(1);
	printf("\n");
	tagCnt = heapSize();

	for(i = 0; i < tagCnt; i++) // Prints values to produce the integer values in descending order.
	{
	del = heapDelete();
	push(del);
	printf( "%d \n", del);
	}

	printf("\n");

	for(i = 0; i < tagCnt; i++)
	{
	printf( "%d \n", pop());
	}

  exit(0);
}