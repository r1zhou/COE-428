// Raymond Zhou
// XXXX20889

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

/**
 *  The functions in this module implement a Heapdata structure
 *  of integers.
 */

static int size = 0;
int heap[100];

void sortHeap(int p)

/** maintains heap structure by ensuring parent value is higher than children (maxHeap) 
recursively called until condition satisfied. **/

{
	int temp;
	int left = (2*p) + 1;
	int right = (2*p) + 2;
	int largest = p;

	if ((left < size) && (heap[left] > heap[largest]))
		largest = left;

	if ((right < size) && (heap[right] > heap[largest]))
		largest = right;

	if (largest != p) 
	{
		temp = heap[largest];
		heap[largest] = heap[p];
		heap[p] = temp;
		sortHeap(largest);
	}
}

/**
 * heapDelete() removes the biggest integer in the heap and returns it.
 **/

int heapDelete() 

/** Deletes highest integer in heap (ie. heap[0]), returns value.
When top of heap is deleted, the last item will replace it.
calls functon heapify (sortHeap()) for each node that affects the heap property of tree. **/
{
	int i;
	int temp;
	int send;

	send = heap[1];
	heap[1] = heap[size];
	heap[size] = send;
	size -= 1;

	for (i = 1; i <= size / 2; i = i)		
	{									
		if ((2 * i + 0 <= size) && (heap[i] < heap[2 * i]) && (heap[2 * i] > heap[2 * i + 1]))
		{
			temp = heap[i];
			heap[i] = heap[2 * i];
			heap[2 * i] = temp;
			i = 2 * i;
		}
		else if ((2 * i + 1 <= size) && (heap[i] < heap[2 * i + 1]) && (heap[2 * i] < heap[2 * i + 1]))
		{
			temp = heap[i];
			heap[i] = heap[2 * i + 1];
			heap[2 * i + 1] = temp;
			i = 2 * i + 1;
		}
		else
			i = 99;		
        }												
	return send;
}
/** {
	int temp;
	temp = heap[0];
	heap[0] = heap[size];
	heap[size] = temp;
	sortHeap(0);
	size--;
	return heap[size+1];
} **/

/**
 *  addHeap(thing2add) adds the "thing2add" to the Heap.
 **/

void addHeap(int thing2add)

/** adds "things2add" to heap, while maintaining heap structure. checks things2add with 
its parent and swaps until it reaches top of the heap tree. **/

{
	int i;
	int temp;
	size += 1;
	heap[size] = thing2add;
	heap[0] = heap[size];

	for (i = size / 2; i >= 1; i--)
	{
		if ((2 * i + 0 <= size) && (heap[i] < heap[2 * i]))
		{
			temp = heap[i];
			heap[i] = heap[2 * i];
			heap[2 * i] = temp;

			if (2 * i <= size / 2)					
				i = 2 * i + 1; 																	
		}
		else if ((2 * i + 1 <= size) && (heap[i] < heap[2 * i + 1]))
		{
			temp = heap[i];
			heap[i] = heap[2 * i + 1];
			heap[2 * i + 1] = temp;

			if (2 * i + 1 <= size / 2)
				i = 2 * i + 2;
		}
	}
}

/**
 * heapSize() returns the number of items in the Heap.
 *
 */
int heapSize() // Returns number of items in heap
{
	return size;  //A dummy return statement
}

void printTree(int s)

/** prints tree structure as XML expression. Gets position it wants to print and prints opening tag. Recursive
calling for right and left children and ends by printing its end tag. Called in main with printHeap(0). **/

{
	while (s <= size)
	{
		printf( "<node id = \"%d\"> ", heap[s]);
		if (2 * s <= size)
			printTree(2 * s);
		if (2 * s + 1 <= size)
			printTree(2 * s + 1);
		s = size + 1;
	}

	printf( "</node> ");
}